﻿using System;
using EngineeringService;

// Two-way Adapter Pattern Pierre-Henri Kuate and Judith Bishop Aug 2007
// Embedded system for a SeaBird flying plane

namespace EngineeringService
{

    //ITarget interface
    public interface IAircraft
    {
        bool Airborne { get; }
        void TakeOff();
        int Height { get; }
        void changeNoseAngle(int newAngle);
        int NoseAngle { get; set; }
    }

    // Target 
    public sealed class Aircraft : IAircraft
    {
        const int TAKEOFF_HEIGHT_M = 200;
        int height;
        bool airborne;
        int noseangle; //added this

        public Aircraft()
        {
            height = 0;
            airborne = false;
            noseangle = 0; //added this
        }

        public void TakeOff()
        {
            Console.WriteLine("Aircraft engine takeoff");
            airborne = true;
            height = TAKEOFF_HEIGHT_M; //metres
        }

        public bool Airborne
        {
            get { return airborne; }
        }

        public int Height
        {
            get { return height; }
        }

        public int NoseAngle
        {
            get { return noseangle; }
            set { noseangle = value; }
        }

        //Added this method
        public void changeNoseAngle(int newAngle)
        {
            noseangle = newAngle;
        }
    }
}  // end of EngineeringService

//Adaptee interface
public interface ISeacraft
{
    int Speed { get; set; }
    
    void IncreaseRevs();
    void StopCraft();

    //void IncreaseHeight();
}

// Adaptee   
public class Seacraft : ISeacraft
{
    int speed = 0;
    //introducing a meaningfully named variable for 
    //the Increase amount is part of refactoring
    const int SPEED_INCREASED_STEP = 10;

    public virtual void IncreaseRevs()
    {
        speed += SPEED_INCREASED_STEP;
        Console.WriteLine("Seacraft engine increases revs to " + speed + " knots");
    }

    public virtual void DecreaseRevs()
    {
        speed -= SPEED_INCREASED_STEP;
    }

    public virtual void StopCraft()
    {
        speed = 0;        
    }

    public int Speed
    {
        get { return speed; }
        set { speed = value; } //had to add this so speed could be changed by seaBird
    }

   
}

//Adapter
public class Seabird : Seacraft, IAircraft
{
    int height = 0;
    int noseangle;
    // A two-way adapter hides and routes the Target's methods
    //  Use Seacraft instructions to implement this one 
    public void TakeOff()
    {
        while (!Airborne)
            IncreaseRevs();
    }

    //Routes this straight back to the Aircraft
    public int Height
    {
        get { return height; }
    }

    public int NoseAngle
    {
        get { return noseangle; }
        set { noseangle = value; }
    }

    //Creating this method is part of refactoring since it keeps each method performing
    //one specific function, making the IncreaseRevs() method within Seabird shorter
    public void IncreaseHeight()
    {
        //creating named constants for speedThreshold and heightIncreaseAmount
        //is part of refactoring
        const int SPEED_THRESHOLD_KMH = 40;
        const int HEIGHT_INCREASED_AMOUNT_M = 100;

        if (Speed > SPEED_THRESHOLD_KMH)
            height += HEIGHT_INCREASED_AMOUNT_M;
    }

    // This method is common to both Target and Adaptee
    public override void IncreaseRevs()
    {
        base.IncreaseRevs();
        IncreaseHeight();       
    }

    public override void StopCraft()
    {
        base.StopCraft();
    }

    public void changeNoseAngle(int newAngle)
    {
        noseangle = newAngle;
        
    }

    public bool Airborne
    {
        get {
             //Creating a named constant for takeOffHeight is part of refactoring
             const int TAKEOFF_HEIGHT_M = 50;
             return height > TAKEOFF_HEIGHT_M; 
        }
    }

    //public void StopCraft()
    //{
    //    Speed = 0;
    //}
}

class InventorTest
{
    //Refactoring Main method using Extract method by
    //TestAirCraftEngine(), TestSeaBirdEngine(), and IncreaseSpeedOfSeaBird(IAircraft seabird)
    //which can reduce the Cyclomatic Complexity to 1 from 3.
    static void Main()
    {
        // No adapter
        TestAirCraftEngine();

        // Classic usage of an Adapter
        IAircraft seabird = TestSeaBirdEngine();

        // Two-way adapter: using seacraft instructions on an IAircraft object
        // (where they are not in the IAricraft interface)
        IncreaseSpeedOfSeaBird(seabird);

        IAircraft seabird2 = AccelerateSeaBird();
        StopSeaCraft(seabird2);   
        
        
        Console.ReadKey();
    }

    private static void TestAirCraftEngine()
    {
        // No adapter
        Console.WriteLine("Experiment 1: test the aircraft engine");
        IAircraft aircraft = new Aircraft();
        aircraft.TakeOff();
        if (aircraft.Airborne)
            Console.WriteLine("The aircraft engine is fine, flying at " + aircraft.Height + "metres");
    }
    private static IAircraft TestSeaBirdEngine()
    {
        // Classic usage of an Adapter
        Console.WriteLine("\nExperiment 2: Use the engine in the SeaBird");
        IAircraft seabird = new Seabird();
        seabird.TakeOff(); // and automatically increases speed
        Console.WriteLine("The SeaBird took off");
        return seabird;
    }
    private static void IncreaseSpeedOfSeaBird(IAircraft seabird)
    {
        Console.WriteLine("\nExperiment 3: Increase the speed of the Seabird:");
        (seabird as ISeacraft).IncreaseRevs();
        (seabird as ISeacraft).IncreaseRevs();
        if (seabird.Airborne)
            Console.WriteLine("Seabird flying at height " + seabird.Height +
                        " metres and speed " + (seabird as ISeacraft).Speed + " knots");
        Console.WriteLine("Experiments successful; the Seabird flies!");
    }

    private static IAircraft AccelerateSeaBird()
    {
        Seabird seabird2 = new Seabird();
        
        //IAircraft seabird2 = new Seabird();
        //A single call of IncreaseRevs will accelerate to a slow speed;
        
        (seabird2 as ISeacraft).IncreaseRevs();
        Console.WriteLine("Accelerate seabird 2 to slow speed of " + (seabird2 as ISeacraft).Speed + " knots");
        return seabird2;
        
    }

    private static void StopSeaCraft(IAircraft seabird2)
    {
        //(seabird2 as ISeacraft).Speed = 0;
        (seabird2 as ISeacraft).StopCraft();
        Console.WriteLine("seabird 2 at speed of " + (seabird2 as ISeacraft).Speed + " knots");
        (seabird2 as ISeacraft).IncreaseRevs();
        (seabird2 as ISeacraft).IncreaseRevs();
        (seabird2 as ISeacraft).IncreaseRevs();
        Console.WriteLine("seabird 2 at high speed of " + (seabird2 as ISeacraft).Speed + " knots");

        (seabird2 as IAircraft).changeNoseAngle(20); //increase noseAngle to positive twenty degrees
        Console.WriteLine("seabird 2 nose angle is " + (seabird2 as IAircraft).NoseAngle + " degrees.");
        seabird2.TakeOff(); // and automatically increases speed
        Console.WriteLine("seabird2 took off");
        Console.WriteLine("seabird2 height is " + (seabird2 as IAircraft).Height);
        (seabird2 as Seabird).IncreaseHeight();
        Console.WriteLine("seabird2 height increased to " + (seabird2 as IAircraft).Height);
        //Increase Height Again
        (seabird2 as Seabird).IncreaseHeight();
        Console.WriteLine("seabird2 height increased to " + (seabird2 as IAircraft).Height);
        //Change nose angle to something lower to prepare for landing
        (seabird2 as IAircraft).changeNoseAngle(10); //increase noseAngle to positive twenty degrees
        Console.WriteLine("seabird 2 nose angle is " + (seabird2 as IAircraft).NoseAngle + " degrees.");
        Console.WriteLine("seabird 2 at speed of " + (seabird2 as ISeacraft).Speed + " knots");
        (seabird2 as Seabird).DecreaseRevs();
        Console.WriteLine("seabird 2 at speed of " + (seabird2 as ISeacraft).Speed + " knots");
    }


}

/* Output
Experiment 1: test the aircraft engine
Aircraft engine takeoff
The aircraft engine is fine, flying at 200metres

Experiment 2: Use the engine in the SeaBird
Seacraft engine increases revs to 10 knots
Seacraft engine increases revs to 20 knots
Seacraft engine increases revs to 30 knots
Seacraft engine increases revs to 40 knots
Seacraft engine increases revs to 50 knots
The SeaBird took off

Experiment 3: Increase the speed of the Seabird:
Seacraft engine increases revs to 60 knots
Seacraft engine increases revs to 70 knots
Seabird flying at height 300 metres and speed 70 knots
Experiments successful; the Seabird flies!
*/